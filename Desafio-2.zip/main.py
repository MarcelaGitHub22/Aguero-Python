import json
def menu():
  print("1- agregar proyecto")
  print("2- agregar tareas")
  print("3- agregar miembros")
  print("4- mostrar proyectos")
  print("5- Salir")
  opcion=int(input("Ingrese Opcion"))
  return opcion



def agregar_proyecto():
  nombre = input("ingrese el nombre del proyecto: ")
  proyectos[nombre] = {"miembros":[], "tareas":[],"fecha_limite": ""}
  fecha = input("a que fecha desea que se realice el proyecto: ")
  proyectos[nombre]["fecha_limite"] = fecha
  
pass

def agregar_tareas():
  nombre = input("ingrese el nombre del proyecto: ")
  tarea = input("ingrese el nombre de la tarea: ")
  proyectos[nombre]["tareas"].append(tarea)
pass

def agregar_miembro():
  nombre = input("ingrese el nombre del proyecto: ")
  miembro = input("ingrese el numbre del miembro")
  proyectos[nombre]["miembros"].append(miembro)
pass

  

proyectos ={}
while True:
  op=menu()
  if op==1:
    agregar_proyecto()
  
  elif op==2:
    agregar_tareas()
  elif op==3:
    agregar_miembro()

  elif op ==4:
    #print(proyectos)
    with open("tareas.json", "w") as archivo:
      json.dump(proyectos, archivo, indent=4)
    
    with open("tareas.json", "r") as archivo:
      contenido = json.load(archivo)
      print(contenido)
      
  elif op==5:
      break


  

